<!DOCTYPE html>
<html>
<body>

<?php
function writeMsg() {
  echo "Hello world!";
  echo "developer4"
  echo "developer0004"
}

writeMsg();
?>

</body>
<h1>  This is dev4 Code  </h1>
  <h1>  This is dev4 Code  </h1>
  <h1> This is dev4 Code </h1>
</html>

<!DOCTYPE html>
<html>
<body>

<?php
function writeMsg() {
  echo "Hello world!";
  echo "developer05"
  echo "developer0005"
  echo "code add developer 5"
}

writeMsg();
?>
