<!DOCTYPE html>
<html>
<body>

<?php
function writeMsg() {
  echo "Hello world!";
}

writeMsg();
?>

</body>
<h1>  This is dev4 Code  </h1>
  <h1>  This is dev4 Code  </h1>
  <h1> This is dev4 Code </h1>
</html>

<!DOCTYPE html>
<html>
<body>

<?php
function writeMsg() {
  echo "Hello world!";
}

writeMsg();
?>
